public class HelloWorld
{
    public String getString()
    {
        return "Hello Jack！";
    }
}