package com.pinpointgrowth.DTO;

public class RubricDTO {
	private int rubricID;
	private String rubricName;

	public int getRubricID() {
		return rubricID;
	}

	public void setRubricID(int rubricID) {
		this.rubricID = rubricID;
	}

	public String getRubricName() {
		return rubricName;
	}

	public void setRubricName(String rubricName) {
		this.rubricName = rubricName;
	}

}
