package mypao;
import java.io.*;
public class Hello
{  int x;
    public Hello(){
        x=200;
    }
    public int getX(){
        return x;
    }
    public void setX(int newX){
        x=newX;
    }
    public String print(){
     return "Hi,Xiaoran";
    }
}