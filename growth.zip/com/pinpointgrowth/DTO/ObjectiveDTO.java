package com.pinpointgrowth.DTO;

public class ObjectiveDTO {

	private int objectiveID;
	private String objectiveName;
	private String description;
	private int weight;
	private int minScore;
	private int maxScore;
	private int performanceScore;

	public int getObjectiveID() {
		return objectiveID;
	}

	public void setObjectiveID(int objectiveID) {
		this.objectiveID = objectiveID;
	}

	public String getObjectiveName() {
		return objectiveName;
	}

	public void setObjectiveName(String objectiveName) {
		this.objectiveName = objectiveName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getMinScore() {
		return minScore;
	}

	public void setMinScore(int minScore) {
		this.minScore = minScore;
	}

	public int getMaxScore() {
		return maxScore;
	}

	public void setMaxScore(int maxScore) {
		this.maxScore = maxScore;
	}

	public int getPerformanceScore() {
		return performanceScore;
	}

	public void setPerformanceScore(int performanceScore) {
		this.performanceScore = performanceScore;
	}

}
